# Little Lemon Web Application

This project is a capstone project for the Coursera Full Stack Development course. It implements a web application for the Little Lemon restaurant with functionalities for menu management and table booking.

## API Endpoints

- `/api/menu/`
- `/api/bookings/`
- `/auth/`

## Setup and Installation

1. Clone the repository.
2. Create a virtual environment using `pipenv` and install dependencies.
3. Configure the MySQL database in `settings.py`.
4. Run migrations.
5. Start the Django development server.
6. Test the API endpoints using Insomnia or any other REST client.

## Unit Tests

Unit tests are provided in `tests.py`. Run them using the Django test runner.

## Authentication

Token-based authentication is implemented using Djoser and DRF. Obtain a token by logging in through the provided endpoints.

## License

This project is licensed under the MIT License.
