from django.test import TestCase
from django.contrib.auth.models import User
from .models import Menu, Booking

class MenuTest(TestCase):
    def setUp(self):
        Menu.objects.create(name="Test Menu", description="Test Description", price=10.99)

    def test_menu_creation(self):
        menu = Menu.objects.get(name="Test Menu")
        self.assertEqual(menu.description, "Test Description")

class BookingTest(TestCase):
    def setUp(self):
        user = User.objects.create(username="testuser")
        Booking.objects.create(user=user, date="2023-08-01", time="18:00:00", party_size=4)

    def test_booking_creation(self):
        booking = Booking.objects.get(date="2023-08-01")
        self.assertEqual(booking.party_size, 4)
